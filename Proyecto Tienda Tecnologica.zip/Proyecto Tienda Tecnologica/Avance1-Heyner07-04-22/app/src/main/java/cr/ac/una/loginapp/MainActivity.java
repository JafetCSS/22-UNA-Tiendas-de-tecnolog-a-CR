package cr.ac.una.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.*; //the password using ReGex (expresiones regulares)

public class MainActivity extends AppCompatActivity {

    EditText editText_username;
    EditText editText_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.editText_username = findViewById(R.id.txt_username);
        this.editText_password = findViewById(R.id.txt_password);
    }

    public void checkData(View view) {
        final String USERNAME = "admin";
        final String PASSWORD = "Hey@lei123";

        String username = this.editText_username.getText().toString();
        String password = this.editText_password.getText().toString();

        if (!this.editText_username.getText().toString().isEmpty() && !this.editText_password.getText().toString().isEmpty()) {

            if (validatePassword(password) != false) {

                if (USERNAME.equals(username) && PASSWORD.equals(password)) {
                    Toast.makeText(this, "Te damos la bienvenida", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Los datos son incorrectos!", Toast.LENGTH_SHORT).show();
                    this.editText_username.setText("");
                    this.editText_password.setText("");
                }

            } else {
                this.editText_username.setText("");
                this.editText_password.setText("");
                Toast.makeText(this, "Formato de contrasenia Invalido,Debe contener numeros 0-9,caracteres especial(/#@%$&+=),letra A-Z y a-z", Toast.LENGTH_SHORT).show();
            }

        } else {
            Toast.makeText(this, "Debe completar los espacios", Toast.LENGTH_LONG).show();
        }
    }

    private boolean validatePassword(String password) {
        //expresion regular para validar la contrasenia
        String regex = "^(?=.*[0-9])"
                + "(?=.*[a-z])(?=.*[A-Z])"
                + "(?=.*[@#$%^&+=])"
                + "(?=\\S+$).{8,20}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        //retorna true si el pw cumple el formato caso contrario false
        System.out.println(matcher.matches());
        return matcher.matches();
    }
}