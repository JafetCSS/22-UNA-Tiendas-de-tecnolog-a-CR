<?php

include_once "./categorybusiness.php";
include_once "../domain/category.php";

if (isset($_POST['categoryname']) && isset($_POST['categorystatus'])) {

    $categorybusiness = new CategoryBusiness();
    $result = $categorybusiness->saveCategory(new Category(0, $_POST['categoryname'], $_POST['categorystatus']));
    echo $result;
}

if (isset($_POST['update'])) {

    $categorybusiness = new CategoryBusiness();

    if (strlen($_POST['id_category']) > 0 && strlen($_POST['category_name']) > 0 && strlen($_POST['category']) > 0) {
        $result = $categorybusiness->updateCategory(new Category($_POST['id_category'], $_POST['category_name'], $_POST['category']));
        if ($result == 1) {
            header("Location: ../view/addcategoryview.php?message=updated");
        } else {
            header("Location: ../view/addcategoryview.php?message=dberror");
        }
    } else {
        header("Location: ../view/addcategoryview.php?message=empty");
    }
} else if (isset($_POST['delete'])) {

    $categorybusiness = new CategoryBusiness();
    $result = $categorybusiness->deleteCategory($_POST['id_category']);
    if ($result == 1) {
        header("Location: ../view/addcategoryview.php?message=deleted");
    }else{
        header("Location: ../view/addcategoryview.php?message=dberror");
    }
}
