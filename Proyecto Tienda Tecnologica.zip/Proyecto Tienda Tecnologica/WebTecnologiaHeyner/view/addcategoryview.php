<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista Categorias</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <?php
    include_once "../business/categorybusiness.php";
    ?>
    <style>
        body {
            background-color: #f0f2f5;
        }

        .table-responsive {
            width: 100%;
            height: 400px;
        }
    </style>

</head>

<body>

    <nav class="navbar navbar-dark bg-dark">
        <ul class="nav navbar-dark bg-dark">
            <li class="nav-item">
                <a class="nav-link" href="../view/index.php">Inicio</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="../view/addcategoryview.php">Gestionar Categorias</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../view/addsubcategoryview.php">Gestionar Subcategorias</a>
            </li>
        </ul>

    </nav>

    <div class="container">
        <h3>Registro Categoria</h3>

        <form class="requires-validation" novalidate>

            <div class="col-md-12">
                <input class="form-control" type="text" name="category_name" id="category_name" placeholder="Nombre Categoria" required>

            </div>

            <div class="col-md-12">
                <select class="form-select mt-3" id="category" required>
                    <option selected disabled value="estado">Estado</option>
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>

                </select>
            </div>


            <div class="form-button mt-3">
                <button id="create_category" type="button" class="btn btn-primary">Register</button>
            </div>
        </form>
        <br>
        <div class="row">
            <div class="col-xs-6 text-center">

                <?php
                $categorybusiness = new CategoryBusiness();
                $allcategories = $categorybusiness->getAllCategory();
                ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Categoria</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allcategories as $category) { ?>
                                <?php echo '<form action="../business/categoryaction.php" method="POST">'; ?>
                                <tr>
                                    <input type="hidden" name="id_category" value="<?php echo $category->getIdCategory() ?>">
                                    <td><input type="text" name="category_name" class="form-control" value="<?php echo $category->getNameCategory() ?>"></td>

                                    <td><select name="category" id="category" class="form-select">
                                            <option selected disabled value="estado">Estado</option>
                                            <option value="activo" <?php if (strcmp($category->getStatusCategory(), 'activo') == 0) {
                                                                        echo "selected";
                                                                    } ?>>Activo</option>
                                            <option value="inactivo" <?php if (strcmp($category->getStatusCategory(), 'inactivo') == 0) {
                                                                            echo "selected";
                                                                        } ?>>Inactivo</option>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="submit" value="Actualizar" name="update" id="update" class="btn btn-warning">
                                        <input type="submit" value="Eliminar" name="delete" id="delete" class="btn btn-danger" />
                                    </td>
                                </tr>
                                <?php echo '</form>' ?>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
                <div>
                    <?php
                    if (isset($_GET['message'])) {
                        if (strcmp($_GET['message'], 'empty') == 0) {
                            echo "<p style='color:red'>*Campos vacios, no se puede actualizar*</p>";
                        } else if (strcmp($_GET['message'], 'dberror') == 0) {
                            echo "<p style='color:red'>Error no se pudo actualizar los datos!</p>";
                        }
                    }
                    ?>
                </div>

            </div>

        </div>

    </div>

    <script src="../js/addCategory.js"></script>
</body>

</html>