
var btn = document.getElementById('create_category');
btn.addEventListener('click', function () {

    if (document.getElementById('category_name').value != '' && document.getElementById('category').value != 'estado') {

        const postData = {
            categoryname: document.getElementById('category_name').value,
            categorystatus: document.getElementById('category').value
        };

        const url = '../business/categoryaction.php';
        $.post(url, postData, (response) => {
            if (response == 0) {
                window.location.href = "../view/addcategoryview.php";
            }
        });

    }else{
        alert('No se inserto, asegurese de completar el formulario');
    }

});

