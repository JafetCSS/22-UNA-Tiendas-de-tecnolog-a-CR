
var button = document.getElementById('create-subcategory');
button.addEventListener('click', function () {

    if (document.getElementById('subcategory_name').value != '' && document.getElementById('category_root').value != 0
        && document.getElementById('subcategory-status').value != 'estado') {

        const post_Data = {
            subcategoryname: document.getElementById('subcategory_name').value,
            categoryid: document.getElementById('category_root').value,
            subcategorystatus: document.getElementById('subcategory-status').value
        };

        const urltosend = '../business/subcategoryaction.php';
        $.post(urltosend, post_Data, (response) => {
            // console.log(`Res ${response}`);
            if (response == 0) {
                window.location.href = "../view/addsubcategoryview.php";
            }
        });

    } else {
        alert('No se inserto, debe completar el formulario');
    }



});
